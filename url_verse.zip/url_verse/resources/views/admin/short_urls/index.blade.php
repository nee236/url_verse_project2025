@extends('layouts.master')

@section('title', 'Client Admin Dashboard')

@section('content')
<div class="content-wrapper">
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-12 d-flex align-items-center">
                <h5 class="fw-bold mb-0">Generated Short URLs</h5>
                <button class="btn btn-primary btn-sm ms-3" data-bs-toggle="modal" data-bs-target="#generateUrlModal">
                    Generate
                </button>
                <div class="ms-auto">
                    <select class="form-select form-select-sm d-inline-block w-auto">
                        <option selected>This Month</option>
                        <option>Last Month</option>
                        <option>Last Week</option>
                        <option>Today</option>
                    </select>
                    <button class="btn btn-primary btn-sm ms-2">Download</button>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Short URL</th>
                                        <th>Long URL</th>
                                        <th>Hits</th>
                                        <th>Created By</th>
                                        <th>Created On</th>
                                    </tr>
                                </thead>
                                <tbody id="shortUrlsTable">
                                    @foreach($shortUrls as $url)
                                    <tr>
                                        <td>{{ url('/s/' . $url->short_code) }}</td>
                                        <td>{{ Str::limit($url->original_url, 30) }}</td>
                                        <td>0</td>
                                        <td>User {{ $url->user_id }}</td>
                                        <td>{{ $url->created_at->format('d M \'y') }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex align-items-center mt-3">
                            <div>Showing {{ $shortUrls->count() }} of total 1200</div>
                            <button class="btn btn-primary btn-sm ms-2">View All</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Generate URL Modal -->
<div class="modal fade" id="generateUrlModal" tabindex="-1" aria-labelledby="generateUrlModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="generateUrlModalLabel">Generate Short URL</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="generateUrlForm">
                    @csrf
                    <div class="mb-3">
                        <label for="original_url" class="form-label">Enter Long URL</label>
                        <input type="url" class="form-control" id="original_url" name="original_url" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Generate</button>
                </form>
                <div id="shortUrlResult" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
    $(document).ready(function() {
        $('#generateUrlForm').submit(function(e) {
            e.preventDefault();
            let formData = $(this).serialize();

            $.ajax({
                url: "{{ route('short-urls.store') }}",
                type: "POST",
                data: formData,
                success: function(response) {
                    $('#shortUrlResult').html('<div class="alert alert-success">Short URL: <a href="' + response.short_url + '" target="_blank">' + response.short_url + '</a></div>');
                    $('#generateUrlForm')[0].reset();
                },
                error: function(xhr) {
                    alert('Error generating short URL');
                }
            });
        });
    });
</script>
@endsection
