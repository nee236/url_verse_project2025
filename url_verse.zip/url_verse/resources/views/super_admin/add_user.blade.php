<!-- resources/views/super_admin/add_user.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Add User</title>
</head>
<body>
    <h1>Add Client Admin or Member</h1>
    @if ($errors->any())
        <div>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('super-admin.store-user') }}">
        @csrf
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="{{ old('name') }}" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="{{ old('email') }}" required><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>

        <label for="role_id">Role:</label>
        <select id="role_id" name="role_id" required>
            <option value="2" {{ old('role_id') == '2' ? 'selected' : '' }}>Client Admin</option>
            <option value="3" {{ old('role_id') == '3' ? 'selected' : '' }}>Client Member</option>
        </select><br>

        <button type="submit">Add User</button>
    </form>
</body>
</html>
