@extends('layouts.master')
@section('title', 'Welcome to My Website')
@section('content')
<div class="content-wrapper">
   <div class="container">
      <div class="row mb-3">
         <div class="col-md-9">
         <h4 class="fw-bold mb-0 text-success">Super Admin Dashboard</h4>
           
         </div>
         <!-- <div class="col-md-3 text-end">
            <a class="btn btn-primary btn-sm" href=" route('super-admin.add-user') ">Add New User</a>
         </div> -->
      </div>
      <hr/>
      @if(session('success'))
      <div class="alert alert-success alert-dismissible fade show" role="alert">
         {{ session('success') }}
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      @endif
      <div class="row">
         <div class="col-md-12">
            <!-- Clients Table -->
            <div class="panel panel-default">
               <div class="panel-heading d-flex justify-content-between align-items-center">
               <h5 class="fw-bold mb-0 text-primary">Clients</h5>
                  <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#inviteModal">Invite Link</button>
               </div>
               <div class="panel-body" style="margin-top: 20px;">
                  <div class="table-responsive">
                     <table class="table table-striped table-bordered" id="dataTables-example">
                        <thead>
                           <tr>
                              <th>S No</th>
                              <th>Client Name</th>
                              <th>Users</th>
                              <th>Total Generated URLs</th>
                              <th>Total URL Hits</th>
                           </tr>
                        </thead>
                        <tbody>
                        @foreach($clients as $index => $client)
                           <tr>
                              <td>{{ $index + 1 }}</td>
                              <td>{{ $client->name }}</td>
                              <td>{{ $client->users_count }}</td>  <!-- Display user count with role_id 2 or 3 -->
                              <td>{{ $client->total_generated_urls ?? 0 }}</td> <!-- Display total generated URLs -->
                              <td>{{ $client->total_url_hits ?? 0 }}</td> <!-- Add logic for URL hits -->
                           </tr>
                        @endforeach
                        </tbody>
                     </table>
                  </div>
                   <!-- Pagination and View All -->
                   <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>Showing {{ $clients->firstItem() }} to {{ $clients->lastItem() }} of {{ $clients->total() }} entries</div>
                    <form action="{{ route('super-admin.clients') }}" method="get" style="display:inline;">
                        <button type="submit" class="btn btn-sm btn-primary">View All</button>
                     </form>
                    {{ $clients->links() }}
                </div>
               </div>
            </div>
            <!-- End Clients Table -->
         </div>
      </div>
   </div>
</div>

<!-- Generated URLs Section -->
<div class="content-wrapper-two" style="margin-top: 30px;">
   <div class="container">
      <div class="row mb-3">
         <div class="col-md-12 d-flex align-items-center">
            <h5 class="fw-bold mb-0 text-primary">Generated Short URLs</h5>
          
            <div class="ms-auto">
               <form action="{{ route('super-admin.short-urls.export') }}" method="GET">
                  <div class="d-flex">
                        <input type="date" name="start_date" class="form-control form-control-sm me-2">
                        <input type="date" name="end_date" class="form-control form-control-sm me-2">
                        <button type="submit" class="btn btn-primary btn-sm">Download CSV</button>
                  </div>
               </form>
            </div>

         </div>
      </div>

      <div class="row">
         <div class="col-md-12">
             <div class="panel panel-default">
               <div class="panel-body">
                  <div class="table-responsive">
                     <table class="table table-striped table-bordered">
                        <thead>
                           <tr>
                              <th>Short URL</th>
                              <th>Long URL</th>
                              <th>Hits</th>
                              <th>Created By</th>
                              <th>Created On</th>
                           </tr>
                        </thead>
                        <tbody>
                           @foreach($shortUrls as $url)
                               <tr>
                                   <td><a href="{{ url('/s/' . $url->short_code) }}" target="_blank">{{ url('/s/' . $url->short_code) }}</a></td>
                                   <td>{{ $url->original_url }}</td>
                                   <td>{{ $url->hits }}</td>
                                   <td>{{ $url->created_by }}</td>
                                   <td>{{ \Carbon\Carbon::parse($url->created_at)->format('Y-m-d') }}</td>
                               </tr>
                           @endforeach
                        </tbody>
                     </table>
                  </div>
                  <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>Showing {{ $shortUrls->firstItem() }} to {{ $shortUrls->lastItem() }} of {{ $shortUrls->total() }} entries</div>
                    <form action="{{ route('super-admin.admin-short-urls') }}" method="get" style="display:inline;">
                        <button type="submit" class="btn btn-sm btn-primary">View All</button>
                     </form>
                    
                    {{ $shortUrls->links() }}
                </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- End Generated URLs Section -->

<!-- Invite Modal -->
<div class="modal fade" id="inviteModal" tabindex="-1" aria-labelledby="inviteModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="inviteModalLabel">Invite Client Admin</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form id="inviteForm" method="POST" action="{{ route('super-admin.store-client') }}">
               @csrf
               <div class="mb-3">
                  <label for="name" class="form-label">Name</label>
                  <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required>
               </div>
               <div class="mb-3">
                  <label for="email" class="form-label">Email</label>
                  <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required>
               </div>
               <div class="text-end">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Submit</button>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- End Invite Modal -->
@endsection

@push('scripts')
<script>
   document.getElementById('inviteForm').addEventListener('submit', function (e) {
   e.preventDefault(); // Prevent default form submission behavior
   
   const form = e.target;
   const formData = new FormData(form);
   
   fetch("{{ route('super-admin.store-client') }}", {
       method: "POST",
       headers: {
           'X-CSRF-TOKEN': "{{ csrf_token() }}",
           'Accept': 'application/json',
       },
       body: formData
   })
   .then(response => {
       if (!response.ok) {
           throw new Error("An error occurred."); // Handle non-200 HTTP responses
       }
       return response.json();
   })
   .then(data => {
       if (data.message) {
           alert(data.message); // Show a success message
           form.reset(); // Clear the form
           $('#inviteModal').modal('hide'); // Close the modal
       }
   })
   .catch(error => {
       console.error("Error:", error); // Log errors
       alert("Something went wrong. Please try again.");
   });
   });
</script>



@endpush
