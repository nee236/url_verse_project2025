@extends('layouts.master')

@section('title', 'Welcome to My Website')

@section('content')
<div class="content-wrapper">
   <div class="container">
      <div class="row mb-3">
         <div class="col-md-12">
            <h4 class="header-line">Super Admin</h4>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <!-- Clients Table -->
            <div class="panel panel-default">
               <div class="panel-heading">
                  Clients
               </div>
               <div class="panel-body">
                  <div class="table-responsive">
                     <table class="table table-striped table-bordered" id="dataTables-example">
                        <thead>
                           <tr>
                              <th>S No</th>
                              <th>Book Name</th>
                              <th>Category</th>
                              <th>Author</th>
                              <th>ISBN</th>
                              <th>Price (₹)</th>
                              <th>Action</th>
                           </tr>
                        </thead>
                        <tbody>
                           <tr>
                              <td>1</td>
                              <td>
                                 <img src="bookimg/half_gf.jpg" alt="Half Girlfriend" width="100">
                                 <br><b>Half Girlfriend</b>
                              </td>
                              <td>Romantic</td>
                              <td>Chetan Bhagat</td>
                              <td>978-81-291-3572-8</td>
                              <td>195.00</td>
                              <td>
                                 <a href="edit-book.php?bookid=1" class="btn btn-primary btn-sm">
                                    <i class="fa fa-edit"></i> Edit
                                 </a>
                                 <a href="manage-books.php?del=1" onclick="return confirm('Are you sure you want to delete?');" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i> Delete
                                 </a>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </div>
                  <!-- Pagination -->
                  <div class="d-flex justify-content-between align-items-center mt-3">
                     <div>Showing 1 to 4 of 4 entries</div>
                     <nav>
                        <ul class="pagination mb-0">
                           <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                           <li class="page-item active"><a class="page-link" href="#">1</a></li>
                           <li class="page-item disabled"><a class="page-link" href="#">Next</a></li>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
            <!-- End Clients Table -->
         </div>
      </div>
   </div>
</div>
@endsection
