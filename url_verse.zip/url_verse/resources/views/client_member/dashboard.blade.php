@extends('layouts.master')

@section('title', 'Client Admin Dashboard')

@section('content')
<div class="content-wrapper">
   <div class="container">
      <div class="row mb-3">
         <div class="col-md-12 d-flex align-items-center">
            <h5 class="fw-bold mb-0">Generated Short URLs</h5>
            <button class="btn btn-primary btn-sm ms-3" data-bs-toggle="modal" data-bs-target="#shortUrlModal">Generate</button>
            <div class="ms-auto">
               <form action="{{ route('client-member.short-urls.export') }}" method="GET">
                  <div class="d-flex">
                        <input type="date" name="start_date" class="form-control form-control-sm me-2">
                        <input type="date" name="end_date" class="form-control form-control-sm me-2">
                        <button type="submit" class="btn btn-primary btn-sm">Download CSV</button>
                  </div>
               </form>
            </div>

         </div>
      </div>

      <div class="row">
         <div class="col-md-12">
             <div class="panel panel-default">
               <div class="panel-body">
                  <div class="table-responsive">
                     <table class="table table-striped table-bordered">
                        <thead>
                           <tr>
                              <th>Short URL</th>
                              <th>Long URL</th>
                              <th>Hits</th>
                              <th>Created By</th>
                              <th>Created On</th>
                           </tr>
                        </thead>
                        <tbody id="urlTableBody">
                           <!-- URLs will be loaded here via AJAX -->
                        </tbody>
                     </table>
                  </div>
                   <!-- Pagination and View All -->
                   <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>Showing {{ $clients->firstItem() }} to {{ $clients->lastItem() }} of {{ $clients->total() }} entries</div>
                    <form action="{{ route('client-member.admin-short-urls') }}" method="get" style="display:inline;">
                        <button type="submit" class="btn btn-sm btn-primary">View All</button>
                     </form>
                    {{ $clients->links() }}
                </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>



<!-- Short URL Modal -->
<div class="modal fade" id="shortUrlModal" tabindex="-1" aria-labelledby="shortUrlModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="shortUrlModalLabel">Generate Short URL</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form id="shortUrlForm">
               @csrf
               <!-- Hidden Inputs -->
               <input type="hidden" id="role_id" name="role_id" value="{{ auth()->user()->role_id }}">
               <input type="hidden" id="client_id" name="client_id" value="{{ auth()->user()->client_id }}">
               <input type="hidden" id="user_id" name="user_id" value="{{ auth()->user()->id }}">
               
               <div class="mb-3">
                  <label for="originalUrl" class="form-label">Enter Long URL</label>
                  <input type="url" class="form-control" id="originalUrl" name="original_url" required>
               </div>
               <button type="submit" class="btn btn-primary">Generate</button>
            </form>
         </div>
      </div>
   </div>
</div>




<script>
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("shortUrlForm").addEventListener("submit", function(event) {
        event.preventDefault();
        
        let form = this;
        let formData = new FormData(form);

        // Add client_id dynamically from the authenticated user
        formData.append('client_id', {{ auth()->user()->client_id }}); // Assuming you have client_id in your auth data
        

        let originalUrlInput = document.getElementById("originalUrl");
        let modalBody = document.querySelector("#shortUrlModal .modal-body");

        fetch("{{ route('client-member.short-urls.store') }}", {
            method: "POST",
            body: formData,
            headers: {
                "X-CSRF-TOKEN": document.querySelector('input[name="_token"]').value
            }
        })
        .then(response => response.json())
        .then(data => {
            let messageDiv = document.createElement("div");

            if (data.success) {
                // Hide the input field
                originalUrlInput.style.display = "none";

                // Show success message
                messageDiv.classList.add("alert", "alert-success", "mt-3");
                messageDiv.innerText = "✅ Short URL generated successfully: " + data.short_url;

                // Auto-close modal after 3 seconds
                setTimeout(() => {
                    let modal = bootstrap.Modal.getInstance(document.getElementById("shortUrlModal"));
                    modal.hide();
                    location.reload();
                }, 3000);
            } else {
                // Show error message
                messageDiv.classList.add("alert", "alert-danger", "mt-3");
                messageDiv.innerText = "❌ Failed to generate short URL.";
            }

            // Append message
            modalBody.appendChild(messageDiv);
        })
        .catch(error => {
            console.error("Error:", error);
        });
    });

    // Function to fetch short URLs
    function fetchShortUrls() {
    fetch("{{ route('client-member.short-urls.index') }}")
        .then(response => response.json())
        .then(data => {
            if (Array.isArray(data)) {
                let tableBody = document.getElementById('urlTableBody');
                tableBody.innerHTML = ''; // Clear existing rows

                data.forEach(url => {
                    // Construct the full short URL
                    let fullShortUrl = `http://localhost:8000/s/${url.short_code}`;

                    let row = document.createElement('tr');
                    row.innerHTML = `
                        <td><a href="${fullShortUrl}" target="_blank">${fullShortUrl}</a></td>
                        <td>${url.original_url}</td>
                        <td>${url.hits}</td>
                        <td>${url.user ? url.user.name : 'N/A'}</td> <!-- User's name -->
                        <td>${new Date(url.created_at).toLocaleDateString()}</td>
                    `;
                    tableBody.appendChild(row);
                });
            } else {
                console.error("Data is not an array:", data);
            }
        })
        .catch(error => {
            console.error("Error fetching short URLs:", error);
        });
}


    // Fetch short URLs when the page loads
    fetchShortUrls();
});
</script>



@endsection
