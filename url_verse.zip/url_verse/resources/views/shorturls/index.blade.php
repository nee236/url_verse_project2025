@extends('layouts.master')

@section('content')
    <div class="container">
        <h2>Short URLs</h2>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Client ID</th>
                    <th>Role ID</th>
                    <th>Original URL</th>
                    <th>Short Code</th>
                    <th>Hits</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($shortUrls as $shortUrl)
                    <tr>
                        <td>{{ $shortUrl->id }}</td>
                        <td>{{ $shortUrl->user_id }}</td>
                        <td>{{ $shortUrl->client_id }}</td>
                        <td>{{ $shortUrl->role_id }}</td>
                        <td><a href="{{ $shortUrl->original_url }}" target="_blank">{{ $shortUrl->original_url }}</a></td>
                        <td>{{ $shortUrl->short_code }}</td>
                        <td>{{ $shortUrl->hits }}</td>
                        <td>{{ $shortUrl->created_at }}</td>
                        <td>{{ $shortUrl->updated_at }}</td>
                        <td>
                            <a href=" route('shorturls.edit', $shortUrl->id) " class="btn btn-primary">Edit</a>
                            <form action=" route('shorturls.destroy', $shortUrl->id) " method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
