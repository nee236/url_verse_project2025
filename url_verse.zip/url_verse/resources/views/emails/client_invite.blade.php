<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invitation</title>
</head>
<body>
    <h3>Hello {{ $clientName }},</h3>
    <p>You have been invited to join our platform. Please click the link below to sign up:</p>
    
    <!-- Add the sign-up link with the token -->
    <a href="{{ route('client.signup', ['token' => $inviteToken]) }}">Sign Up</a>

    

    <p>This link will expire in 30 minutes.</p>
    <p>Thank you!</p>
</body>
</html>
