<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class SuperAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // Fetch the super_admin role from the database
        $role = DB::table('roles')->where('name', 'super_admin')->first();

        if (!$role) {
            $this->command->error('The "super_admin" role does not exist. Please run the RoleSeeder first.');
            return;
        }

        // Check if the Super Admin user already exists
        $user = User::where('email', 'superadmin@example.com')->first();

        if (!$user) {
            // Create the Super Admin user
            $user = User::create([
                'name' => 'Super Admin',
                'email' => 'superadmin@example.com',
                'password' => Hash::make('password123'),
                'role_id' => $role->id, // Set role_id to the ID of the super_admin role
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Assign the role_id if it is not already set
        if ($user->role_id !== $role->id) {
            $user->role_id = $role->id;
            $user->save();
        }

        $this->command->info('Super Admin user seeded successfully.');
    }
}
