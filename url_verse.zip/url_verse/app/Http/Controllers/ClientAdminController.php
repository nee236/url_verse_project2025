<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Role;
use App\Models\Invitation;
use App\Mail\InviteTeamMemberMail;
use App\Models\TeamMember;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;


class ClientAdminController extends Controller
{
    public function dashboard()
    {

        $clients = DB::table('clients')
    ->join('users', 'users.client_id', '=', 'clients.id')
    ->leftJoin('short_urls', 'short_urls.user_id', '=', 'users.id')
    ->whereIn('users.role_id', [2, 3])  // Role 2 or 3
    ->whereNull('users.team_id')  // Null team_id
    ->select(
        'clients.id',
        'clients.name',
        DB::raw('COUNT(short_urls.id) AS total_generated_urls'),
        DB::raw('SUM(short_urls.hits) AS total_url_hits'),  // Sum of hits
        DB::raw('(SELECT COUNT(*) FROM users WHERE users.client_id = clients.id AND users.role_id IN (2, 3)) as users_count')
    )
    ->groupBy('clients.id', 'clients.name')
    ->paginate(10);  // Paginate results


      // Fetch the short URLs
      $shortUrls = DB::table('short_urls')
      ->join('users', 'users.id', '=', 'short_urls.user_id')
      ->select('short_urls.short_code', 'short_urls.original_url', 'short_urls.hits', 'users.name as created_by', 'short_urls.created_at')
      ->orderBy('short_urls.created_at', 'desc')
      ->paginate(10); // Paginate short URLs

     return view('client_admin.dashboard', compact('clients','shortUrls'));
    
    }
   

    // public function getTeamMembers()
    // {
    //     $teamMembers = User::with('role') // Assuming the 'role' relationship is set up
    //         ->where('client_id', auth()->user()->client_id)
    //         ->get();

    //     return response()->json($teamMembers);
    // }

    public function getTeamMembers()
{
    $teamMembers = DB::table('users')
        ->join('roles', 'roles.id', '=', 'users.role_id') // Join with the 'roles' table to get the role names
        ->leftJoin('short_urls', 'short_urls.user_id', '=', 'users.id') // Left join with the 'short_urls' table to get short URLs data
        ->whereNotNull('users.client_id')  // Ensure that client_id is not null
        ->whereNotNull('users.role_id')    // Ensure that role_id is not null
        ->whereNotNull('users.team_id')    // Ensure that team_id is not null
        ->select(
            'users.id',
            'users.name',
            'users.email',
            'roles.name AS role_name',  // The name of the role (assuming 'roles' table has a 'name' column)
            DB::raw('COUNT(short_urls.id) AS total_urls'), // Count of generated short URLs by the user
            DB::raw('COALESCE(SUM(short_urls.hits), 0) AS total_hits')  // Sum of the total hits for the short URLs, use COALESCE to replace null with 0
        )
        ->groupBy('users.id', 'users.name', 'users.email', 'roles.name')  // Group by user info and role name
        ->get();  // Execute the query and get the result

    // Return the result as a JSON response
    return response()->json($teamMembers);
}

    

    public function invite(Request $request)
{
    // Validate incoming request
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email|max:255|unique:users,email', // Ensure email is unique
        'role_id' => 'required|in:2,3', // Only Admin (2) and Member (3)
        'client_id' => 'required|exists:clients,id', // Ensure client_id is valid
    ]);

    DB::beginTransaction();
    try {
        // Generate a unique invitation token
        $inviteToken = Str::random(32); // You can adjust the length of the token
        
        // Create the invitation record
        $invitation = Invitation::create([
            'client_id' => $request->input('client_id'),
            'role_id' => $request->input('role_id'),
            'invited_by' => auth()->user()->id, // Assuming logged-in user is the inviter
            'email' => $request->input('email'),
            'token' => $inviteToken,
            'expires_at' => Carbon::now()->addMinutes(30), // Invitation expiry time
        ]);

        // Create the team member record
        $teamMember = TeamMember::create([
            'client_id' => $request->input('client_id'),
            'role_id' => $request->input('role_id'),
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'invite_token' => $inviteToken, // Save the token for future validation
        ]);

        // Send the invitation email
        Mail::to($teamMember->email)->send(new InviteTeamMemberMail($teamMember));

        // Commit the transaction
        DB::commit();

        // Respond with success
        return response()->json([
            'success' => true,
            'message' => 'Invitation sent and team member added successfully.',
        ]);
    } catch (\Exception $e) {
        // Rollback in case of error
        DB::rollBack();
        
        // Log the error (optional)
        Log::error('Error in inviting team member: ' . $e->getMessage());

        // Respond with failure
        return response()->json([
            'success' => false,
            'message' => 'Failed to send invitation or add team member.',
        ], 500);
    }
}
    


}
