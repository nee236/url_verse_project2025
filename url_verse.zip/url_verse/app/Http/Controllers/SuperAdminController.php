<?php
// app/Http/Controllers/SuperAdminController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Invitation;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Client;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;


class SuperAdminController extends Controller
{
    public function dashboard()
    {

        $clients = DB::table('clients')
    ->join('users', 'users.client_id', '=', 'clients.id')
    ->leftJoin('short_urls', 'short_urls.user_id', '=', 'users.id')
    ->whereIn('users.role_id', [2, 3])  // Role 2 or 3
    ->whereNull('users.team_id')  // Null team_id
    ->select(
        'clients.id',
        'clients.name',
        DB::raw('COUNT(short_urls.id) AS total_generated_urls'),
        DB::raw('SUM(short_urls.hits) AS total_url_hits'),  // Sum of hits
        DB::raw('(SELECT COUNT(*) FROM users WHERE users.client_id = clients.id AND users.role_id IN (2, 3)) as users_count')
    )
    ->groupBy('clients.id', 'clients.name')
    ->paginate(10);  // Paginate results


      // Fetch the short URLs
      $shortUrls = DB::table('short_urls')
      ->join('users', 'users.id', '=', 'short_urls.user_id')
      ->select('short_urls.short_code', 'short_urls.original_url', 'short_urls.hits', 'users.name as created_by', 'short_urls.created_at')
      ->orderBy('short_urls.created_at', 'desc')
      ->paginate(10); // Paginate short URLs

     return view('super_admin.dashboard', compact('clients','shortUrls'));
    
    }
    

    public function showAddUserForm()
    {
        return view('super_admin.add_user');
    }

    public function storeUser(Request $request)
    {
        // Validate the request
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6',
            'role_id' => 'required|in:2,3', // Only Client Admin and Client Member roles
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        // Create the user
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role_id' => $request->role_id,
        ]);

        return redirect()->route('super-admin.dashboard')->with('success', 'User added successfully!');
    }

    public function storeClient(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:clients,email',
        ]);
    
        // Generate invite token
        $inviteToken = Str::random(32);
    
        // Assume the role is passed as part of the request or set to default role_id (e.g., 2)
        $roleId = $request->input('role_id', 2); // Default to 2 if not provided
    
        // Store in clients table
        $client = Client::create([
            'name' => $request->name,
            'email' => $request->email,
            'invite_token' => $inviteToken,
            'role_id' => $roleId,  // Adding role_id to the invitation
        ]);
    
        // Create the invitation record in the invitations table
        Invitation::create([
            'client_id' => $client->id,
            'role_id' => $roleId,
            'invited_by' => auth()->user()->id,  // Assuming logged-in super admin sends the invite
            'email' => $request->email,
            'token' => $inviteToken,
            'expires_at' => now()->addMinutes(30),  // Token expires in 30 minutes
        ]);
    
        // Send email with the invite link
        $inviteLink = route('client.signup', ['token' => $inviteToken]);
        Mail::to($client->email)->send(new \App\Mail\ClientInvite($client, $inviteToken));
    
        // Redirect back with a success message
        return redirect()
            ->route('super-admin.dashboard')
            ->with('success', 'Client invited successfully!');
    }
    
    public function viewAllClients()
    {
        $clients = DB::table('clients')
        ->join('users', 'users.client_id', '=', 'clients.id')
        ->leftJoin('short_urls', 'short_urls.user_id', '=', 'users.id')
        ->whereIn('users.role_id', [2, 3])  // Role 2 or 3
        ->whereNull('users.team_id')  // Null team_id
        ->select(
            'clients.id',
            'clients.name',
            DB::raw('COUNT(short_urls.id) AS total_generated_urls'),
            DB::raw('SUM(short_urls.hits) AS total_url_hits'),  // Sum of hits
            DB::raw('(SELECT COUNT(*) FROM users WHERE users.client_id = clients.id AND users.role_id IN (2, 3)) as users_count')
        )
        ->groupBy('clients.id', 'clients.name')
        ->paginate(10);  // Paginate results
    
        return view('super_admin.clients', compact('clients'));
    }
    
    
}


