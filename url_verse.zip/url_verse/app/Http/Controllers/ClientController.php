<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Client;
use App\Models\Invitation;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class ClientController extends Controller
{
    // public function sendInvitation(Request $request)
    // {
    //     $token = Str::random(32);
    //     $expiresAt = now()->addMinutes(30);

    //     // Save the token in the invitations table
    //     Invitation::create([
    //         'email' => $request->email,
    //         'token' => $token,
    //         'expires_at' => $expiresAt,
    //         'client_id' => $request->client_id,
    //     ]);

    //     // Generate the signup link
    //     $signupUrl = route('signup.form', ['token' => $token]);

    //     // Send the email
    //     Mail::to($request->email)->send(new \App\Mail\InvitationEmail($signupUrl));

    //     return back()->with('success', 'Invitation sent successfully!');
    // }
    // Show Signup Form
    // public function showSignupForm($token)
    // {
    //     Log::info('Token received: ' . $token);
    //     $client = Client::where('invite_token', $token)->first();
    
    //     if (!$client) {
    //         return redirect()->route('error')->with('message', 'Invalid or expired invite link.');
    //     }
    
    //     return view('auth.client_signup', ['client' => $client]);
    // }

    public function showSignupForm($token)
{
    Log::info('Token received: ' . $token);

    // Fetch invitation using token
    $invitation = Invitation::where('token', $token)->first();

    if (!$invitation) {
        Log::error('Invalid or expired invite token: ' . $token);
        return redirect()->route('error')->with('message', 'Invalid or expired invite link.');
    }

    // Fetch client using client_id from the invitation
    $client = Client::find($invitation->client_id);
    if (!$client) {
        Log::error('Client not found for client_id: ' . $invitation->client_id);
        return redirect()->route('error')->with('message', 'Client not found.');
    }

    Log::info('Client ID:', ['client_id' => $client->id]);
    Log::info('Passing data to view:', ['client' => $client, 'token' => $token]);

      // Debugging output
    //   dd([
    //     'Token' => $token,
    //     'Client ID' => $client->id,
    //     'Client Email' => $client->email,
    // ]);

    return view('auth.client_signup', [
        'client' => $client,
        'invite_token' => $token // Pass token explicitly
    ]);
}



    // Handle Signup Form Submission

    public function handleSignup(Request $request)
{
    // Debugging: Log form input data
    // Log::info('Form data: ', $request->all());
    // storage/logs/laravel.log to check the data
    // [2025-01-29 19:05:58] local.INFO: Form data:  {"_token":"i01IWjwd4wnsvTAYj1YYWsXLUBfbYCnhLGpdVeBZ",
    //     "token":"w6IhoV4L0KXsj871R0n1pduTYxEMOshB","client_id":"1","name":"Sembark Tech","email":"neerajyadav536@gmail.com",
    //     "password":"12345678","password_confirmation":"12345678"} 

    // Alternatively, you can echo the values directly (for testing purposes):
    // echo '<pre>';
    // print_r($request->all()); // Print all input fields
    // echo '</pre>';
    // die;

    // Validate the form data
    $validator = Validator::make($request->all(), [
        'name' => 'required|string|max:255',
        'email' => 'required|email|exists:invitations,email',
        'password' => 'required|string|min:8|confirmed',
        'token' => 'required|string|exists:invitations,token',
        'client_id' => 'required|exists:clients,id' // Validate client_id
    ]);

    // If validation fails
    if ($validator->fails()) {
        return redirect()->back()->withErrors($validator)->withInput();
    }

    // Check if the invitation is valid and not expired
    $invitation = Invitation::where('token', $request->token)
        ->where('expires_at', '>=', now())
        ->first();

    if (!$invitation) {
        return redirect()->route('error')->with('message', 'This invitation link has expired or is invalid.');
    }

    // Create or get the client
    $client = Client::firstOrCreate(['id' => $request->input('client_id')]);

    // Create the user with the received data
    $user = User::create([
        'client_id' => $request->input('client_id'), // Get client_id from the form
        'name' => $request->name,
        'email' => $invitation->email,
        'password' => Hash::make($request->password),
        'role_id' => $invitation->role_id, // Use role_id from the invitation
    ]);

    // Delete the invitation after signup
    //$invitation->delete();

    // Log the user in
    auth()->login($user);

    // Redirect to dashboard
    return redirect()->route('client-admin.dashboard')->with('success', 'Signup successful! Welcome to your team.');
}

    
    
    


}
