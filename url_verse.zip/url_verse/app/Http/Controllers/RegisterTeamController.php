<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; // Import User model
use App\Models\Invitation;
use Carbon\Carbon;
use App\Models\TeamMember;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class RegisterTeamController extends Controller
{
    public function showRegistrationForm($token)
{
    // Validate the token and get the invitation details
    $invitation = Invitation::where('token', $token)
        ->where('expires_at', '>', Carbon::now()) // Ensure the token is not expired
        ->first();

    // If the token is invalid or expired, return an error message
    if (!$invitation) {
        return redirect()->route('home')->with('message', 'Invalid or expired invitation link.');
    }

    // Retrieve the team data for the form using the invitation details
    $team = TeamMember::where('invite_token', $token)->first();

    // If no team member is found, show an error message
    if (!$team) {
        return redirect()->route('home')->with('message', 'Team member data not found.');
    }

    // Pass the team data and the invitation's client data to the view
    return view('auth.team_member_register', [
        'team' => $team,
        'client' => $invitation->client,
        'role_id' => $team->role_id, // Pass the role_id too if needed
        'team_id' => $team->id, // Pass the team_id too if needed
    ]);
}

        // Assuming you're passing the team data to the view
    //     return view('auth.team_member_register', [
    //         'team' => $request->get('team'), // Pass the team data here if needed
    //         'client' => auth()->user() // Assuming the client is the logged-in user
    //     ]);
    // }

    public function handleRegistration(Request $request)
{
    //   echo '<pre>';
    // print_r($request->all()); // Print all input fields
    // echo '</pre>';
    // die;

    // Validate the form data
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email', // Ensure email is unique in users table
        'password' => 'required|string|min:8|confirmed',
        'team_id' => 'required|exists:team_members,id',
        'client_id' => 'required|exists:clients,id',
        'role_id' => 'required|in:2,3', // Assuming role_id can only be Admin (2) or Member (3)
    ]);

    // Create a new user (team member)
    $user = User::create([
        'name' => $request->input('name'),
        'email' => $request->input('email'),
        'password' => Hash::make($request->input('password')),
        'team_id' => $request->input('team_id'), // If the team_id is stored in the users table
        'client_id' => $request->input('client_id'),
        'role_id' => $request->input('role_id'),
    ]);

    // Redirect based on role_id
    if ($user->role_id == 2) {
        // Redirect to the client admin dashboard
        return redirect()->route('client-admin.dashboard');
    } elseif ($user->role_id == 3) {
        // Redirect to the client member dashboard
        return redirect()->route('client-member.dashboard');
    }

    // If no valid role, redirect to the default page (error handling if needed)
    return redirect()->route('some.error.route');
}

}
