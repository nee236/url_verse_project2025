<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ClientMemberController extends Controller
{
    public function dashboard()
    {

        $clients = DB::table('clients')
    ->join('users', 'users.client_id', '=', 'clients.id')
    ->leftJoin('short_urls', 'short_urls.user_id', '=', 'users.id')
    ->whereIn('users.role_id', [2, 3])  // Role 2 or 3
    ->whereNull('users.team_id')  // Null team_id
    ->select(
        'clients.id',
        'clients.name',
        DB::raw('COUNT(short_urls.id) AS total_generated_urls'),
        DB::raw('SUM(short_urls.hits) AS total_url_hits'),  // Sum of hits
        DB::raw('(SELECT COUNT(*) FROM users WHERE users.client_id = clients.id AND users.role_id IN (2, 3)) as users_count')
    )
    ->groupBy('clients.id', 'clients.name')
    ->paginate(10);  // Paginate results


      // Fetch the short URLs
      $shortUrls = DB::table('short_urls')
      ->join('users', 'users.id', '=', 'short_urls.user_id')
      ->select('short_urls.short_code', 'short_urls.original_url', 'short_urls.hits', 'users.name as created_by', 'short_urls.created_at')
      ->orderBy('short_urls.created_at', 'desc')
      ->paginate(10); // Paginate short URLs

     return view('client_member.dashboard', compact('clients','shortUrls'));
    
    }
    
}
