<?php

namespace App\Http\Controllers;

use App\Models\ShortUrl;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Carbon\Carbon;

class ShortUrlController extends Controller
{
    public function index()
    {
        // Fetch the short URLs for the authenticated user, filtering by client_id if needed
        $shortUrls = ShortUrl::where('client_id', auth()->user()->client_id)
                             ->with('user') // Include the associated user data
                             ->get();

        // Return the data as JSON
        return response()->json($shortUrls);
    }
      // Redirect to the original URL and increment the hit count
      public function redirect($short_code)
      {
          // Find the short URL by the short code
          $shortUrl = ShortUrl::where('short_code', $short_code)->first();
  
          // If the short URL exists
          if ($shortUrl) {
              // Increment the hit count
              $shortUrl->hits = $shortUrl->hits + 1; // Increment hits
              $shortUrl->save(); // Save the updated hit count
  
              // Redirect to the original URL
              return redirect()->to($shortUrl->original_url);
          }
  
          // If the short URL doesn't exist, show a 404 page or redirect
          return abort(404, 'Short URL not found');
      }
    public function store(Request $request)
    {
    try {
        // Validate the incoming request
        $request->validate([
            'original_url' => 'required|url',
            'role_id' => 'required|integer',
            'client_id' => 'required|integer',
            'user_id' => 'required|integer',
        ]);

        // Generate a short code (6-character random string)
        $shortCode = Str::random(6); 

        // Create the short URL entry in the database
        $shortUrl = new ShortUrl([
            'user_id' => $request->user_id,
            'client_id' => $request->client_id, // Make sure client_id is properly set
            'role_id' => $request->role_id,
            'original_url' => $request->original_url,
            'short_code' => $shortCode,
        ]);

        // Save to the database
        $shortUrl->save();

        // Prepare the response data (the full short URL)
        $shortUrl->short_url = url('/') . '/' . $shortCode;

        // Return a JSON response with the short URL
        return response()->json([
            'success' => true,
            'short_url' => $shortUrl->short_url
        ]);

    } catch (\Exception $e) {
        // Catch any errors and log them for debugging
        Log::error('Error in store ShortUrl: ' . $e->getMessage());

        // Return a generic error message
        return response()->json([
            'success' => false,
            'message' => 'An error occurred while generating the short URL.'
        ], 500);
    }
    }
    public function export(Request $request)
    {
        // Validate the date input
        $request->validate([
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        // Fetch short URLs with date filter
        $query = ShortUrl::query();

        if ($request->start_date) {
            $query->where('created_at', '>=', Carbon::parse($request->start_date)->startOfDay());
        }

        if ($request->end_date) {
            $query->where('created_at', '<=', Carbon::parse($request->end_date)->endOfDay());
        }

        $shortUrls = $query->get();

        // Generate the CSV file
        $response = new StreamedResponse(function () use ($shortUrls) {
            $output = fopen('php://output', 'w');
            fputcsv($output, ['Short URL', 'Original URL', 'Hits', 'Created At']); // Header row

            foreach ($shortUrls as $url) {
                fputcsv($output, [
                    route('short-url.redirect', ['short_code' => $url->short_code]), // Short URL
                    $url->original_url,
                    $url->hits,
                    $url->created_at->toDateString(), // Format created_at to just the date
                ]);
            }

            fclose($output);
        });

        // Set headers to download as a CSV file
        $response->headers->set('Content-Type', 'text/csv');
        $response->headers->set('Content-Disposition', 'attachment; filename="short_urls.csv"');

        return $response;
    }
    public function shortUrlIndex()
    {
        // Fetch all the records from the short_urls table
        $shortUrls = ShortUrl::all();

        // Return a view and pass the short URLs data to the view
        return view('shorturls.index', compact('shortUrls'));
    }


}
