<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    // Display the login form
    public function showLoginForm()
    {
        return view('auth.login'); // Ensure this matches your login blade file
    }

    // Handle login request
    public function login(Request $request)
    {
        // Validate the input fields
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Get the email and password from the request
        $credentials = $request->only('email', 'password');

        // Attempt to authenticate the user
        if (Auth::attempt($credentials)) {
            // Retrieve the authenticated user's role_id
            $roleId = Auth::user()->role_id;

            // Redirect based on the user's role_id
            switch ($roleId) {
                case 1: // Super Admin Role ID
                    return redirect()->route('super-admin.dashboard');
                case 2: // Client Admin Role ID
                    return redirect()->route('client-admin.dashboard');
                case 3: // Client Member Role ID
                    return redirect()->route('client-member.dashboard');
                default:
                    Auth::logout(); // Log out if the role_id is invalid
                    return redirect('/login')->withErrors(['email' => 'Invalid role. Please contact admin.']);
            }
        }

        // If authentication fails, redirect back with an error
        return back()->withErrors(['email' => 'Invalid credentials']);
    }

    // Logout method
    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }
}
