<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\InviteTeamMemberMail;
use App\Models\User;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class TeamController extends Controller
{
    public function inviteMember(Request $request)
    {
        $request->validate([
            'email' => 'required|email|unique:users,email',
        ]);

        $email = $request->email;
        $inviteToken = Str::random(32);
        $expireTime = Carbon::now()->addMinutes(30); // Token expires in 30 minutes

        // Store the invitation in the database
        DB::table('team_invitations')->insert([
            'email' => $email,
            'token' => $inviteToken,
            'expires_at' => $expireTime,
            'created_at' => now(),
            'updated_at' => now()
        ]);

        // Generate the invite URL
        $inviteUrl = route('register', ['token' => $inviteToken]);

        // Send the invitation email
        Mail::to($email)->send(new InviteTeamMemberMail($inviteUrl));

        return response()->json(['message' => 'Invitation sent successfully.']);
    }
}
