<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShortUrl extends Model
{
    use HasFactory;
     // Define the relationship with the User model
     protected $table = 'short_urls'; // Specify the table if it's not plural by default

     public function user()
     {
         return $this->belongsTo(User::class);
     }
    
    protected $fillable = ['user_id','role_id','client_id', 'original_url', 'short_code'];
    
}
