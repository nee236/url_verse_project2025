<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;
// In Client model
// public function users()
// {
//     return $this->hasMany(User::class, 'client_id'); // Assuming 'client_id' is the foreign key in the users table
// }
 // Assuming your clients table is named 'clients'
 public function users()
 {
     return $this->hasMany(User::class);
 }

 // Relationship to fetch associated short URLs
 public function shortUrls()
 {
     return $this->hasManyThrough(ShortUrl::class, User::class, 'client_id', 'user_id');
 }
    protected $fillable = [
        'role_id',
        'name',
        'email',
        'invite_token',
        'is_signed_up',
    ];
}
