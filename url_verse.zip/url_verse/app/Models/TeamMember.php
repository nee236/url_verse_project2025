<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TeamMember extends Model
{
    protected $table = 'team_members'; // Ensure this matches the actual table name
    use HasFactory;
    // In TeamMember model
    public function role()
    {
        return $this->belongsTo(Role::class);
    }
    protected $fillable = [
        'role_id',
        'client_id', // Add this line
        'name',
        'email',
        'invite_token',
    ];

}
