<?php
namespace App\Mail;

use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class InviteTeamMemberMail extends Mailable
{
    use SerializesModels;

    public $teamMember;

    /**
     * Create a new message instance.
     *
     * @param  \App\Models\TeamMember  $teamMember
     * @return void
     */
    public function __construct($teamMember)
    {
        $this->teamMember = $teamMember;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('You are invited to join the team!')
                    ->view('emails.invite')
                    ->with([
                        'name' => $this->teamMember->name,
                        'email' => $this->teamMember->email,
                        'inviteToken' => $this->teamMember->invite_token,
                    ]);
    }
}

