<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ClientInvite extends Mailable
{
    use Queueable, SerializesModels;

    public $client;
    public $inviteToken;
    public function __construct($client, $inviteToken)
    {
        $this->client = $client;
        $this->inviteToken = $inviteToken;
    }
    
    // In the build method, pass the token to the view
    public function build()
    {
        return $this->view('emails.client_invite')
                    ->with([
                        'clientName' => $this->client->name,
                        'inviteToken' => $this->inviteToken, // Pass the token here
                    ]);
    }
}
