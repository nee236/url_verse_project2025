<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\ClientAdminController;
use App\Http\Controllers\ClientMemberController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ShortUrlController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\AdminShortUrlController;
use App\Http\Controllers\RegisterTeamController;
use Illuminate\Support\Facades\Mail;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/error', function () {
    return view('error');  // The view we will create next
})->name('error');
// Public Routes
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::get('/signup/{token}', [ClientController::class, 'showSignupForm'])->name('client.signup');
Route::post('/signup', [ClientController::class, 'handleSignup'])->name('signup.handle');
Route::get('/s/{short_code}', [ShortUrlController::class, 'redirect'])->name('short-url.redirect');


// For web routes
Route::get('/team_register/{token}', [RegisterTeamController::class, 'showRegistrationForm'])->name('team_register');
Route::post('/signup-team', [RegisterTeamController::class, 'handleRegistration'])->name('signup_team.handle');


Route::post('/invite-member', [TeamController::class, 'inviteMember'])->name('invite.member');

// Authenticated Routes
Route::middleware(['auth'])->group(function () {
    // Logout Route
    Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

    // Super Admin Routes (role_id = 1)
    Route::middleware(['role:1'])->prefix('super-admin')->name('super-admin.')->group(function () {
        Route::get('/dashboard', [SuperAdminController::class, 'dashboard'])->name('dashboard');
        // Route::get('/add-user', [SuperAdminController::class, 'showAddUserForm'])->name('add-user');
        // Route::post('/add-user', [SuperAdminController::class, 'storeUser'])->name('store-user');
        Route::get('/admin-short-urls', [AdminShortUrlController::class, 'index'])->name('admin-short-urls.index');

        Route::post('/add-client', [SuperAdminController::class, 'storeClient'])->name('store-client');
        Route::get('/short-urls/export', [ShortUrlController::class, 'export'])->name('short-urls.export');

        Route::get('/clients', [SuperAdminController::class, 'viewAllClients'])->name('clients');
        Route::get('/short-urls-page', [ShortUrlController::class, 'shortUrlIndex'])->name('admin-short-urls'); // Added missing route

    });

    // Client Admin Routes (role_id = 2)
    Route::middleware(['role:2'])->prefix('client-admin')->name('client-admin.')->group(function () {
        Route::get('/dashboard', [ClientAdminController::class, 'dashboard'])->name('dashboard');

        // Short URLs
    Route::get('/short-urls', [ShortUrlController::class, 'index'])->name('short-urls.index');
    Route::post('/short-urls', [ShortUrlController::class, 'store'])->name('short-urls.store');
    // Invite and Team Members Routes
    Route::post('/invite', [ClientAdminController::class, 'invite'])->name('invite');
    Route::get('/team-members', [ClientAdminController::class, 'getTeamMembers'])->name('team-members.index');
    Route::get('/short-urls/export', [ShortUrlController::class, 'export'])->name('short-urls.export');

    Route::get('/clients', [SuperAdminController::class, 'viewAllClients'])->name('clients');
        Route::get('/short-urls-page', [ShortUrlController::class, 'shortUrlIndex'])->name('admin-short-urls');

 });


    // Client Member Routes (role_id = 3)
    Route::middleware(['role:3'])->prefix('client-member')->name('client-member.')->group(function () {
        Route::get('/dashboard', [ClientMemberController::class, 'dashboard'])->name('dashboard');
        // Short URLs
    Route::get('/short-urls', [ShortUrlController::class, 'index'])->name('short-urls.index');
    Route::post('/short-urls', [ShortUrlController::class, 'store'])->name('short-urls.store');
    Route::get('/short-urls/export', [ShortUrlController::class, 'export'])->name('short-urls.export');
    Route::get('/short-urls-page', [ShortUrlController::class, 'shortUrlIndex'])->name('admin-short-urls');
    });
});


