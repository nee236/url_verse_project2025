<!-- resources/views/super_admin/add_user.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Add User</title>
</head>
<body>
    <h1>Add Client Admin or Member</h1>
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('super-admin.store-user')); ?>">
        <?php echo csrf_field(); ?>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>

        <label for="role_id">Role:</label>
        <select id="role_id" name="role_id" required>
            <option value="2" <?php echo e(old('role_id') == '2' ? 'selected' : ''); ?>>Client Admin</option>
            <option value="3" <?php echo e(old('role_id') == '3' ? 'selected' : ''); ?>>Client Member</option>
        </select><br>

        <button type="submit">Add User</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\url_verse\resources\views/super_admin/add_user.blade.php ENDPATH**/ ?>