

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Short URLs</h2>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Client ID</th>
                    <th>Role ID</th>
                    <th>Original URL</th>
                    <th>Short Code</th>
                    <th>Hits</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $shortUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($shortUrl->id); ?></td>
                        <td><?php echo e($shortUrl->user_id); ?></td>
                        <td><?php echo e($shortUrl->client_id); ?></td>
                        <td><?php echo e($shortUrl->role_id); ?></td>
                        <td><a href="<?php echo e($shortUrl->original_url); ?>" target="_blank"><?php echo e($shortUrl->original_url); ?></a></td>
                        <td><?php echo e($shortUrl->short_code); ?></td>
                        <td><?php echo e($shortUrl->hits); ?></td>
                        <td><?php echo e($shortUrl->created_at); ?></td>
                        <td><?php echo e($shortUrl->updated_at); ?></td>
                        <td>
                            <a href=" route('shorturls.edit', $shortUrl->id) " class="btn btn-primary">Edit</a>
                            <form action=" route('shorturls.destroy', $shortUrl->id) " method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\url_verse\resources\views/shorturls/index.blade.php ENDPATH**/ ?>