<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invitation to Join</title>
</head>
<body>
    <h1>Hello <?php echo e($name); ?>,</h1>
    <p>You have been invited to join the team! Please click the link below to accept the invitation and complete your registration:</p>
    
    <a href="<?php echo e(route('team_register', ['token' => $inviteToken])); ?>">Accept Invitation</a>

    <p>The invitation will expire in 30 minutes.</p>

    <p>Regards,</p>
    <p>Your Team</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\url_verse\resources\views/emails/invite.blade.php ENDPATH**/ ?>