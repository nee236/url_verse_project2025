
<?php $__env->startSection('title', 'All Clients'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
   <div class="container">
      <div class="row mb-3">
         <div class="col-md-9">
            <h4 class="fw-bold mb-0 text-success">All Clients</h4>
         </div>
      </div>
      <hr/>

      <?php if(session('success')): ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
         </div>
      <?php endif; ?>

      <div class="row">
         <div class="col-md-12">
            <!-- Clients Table -->
            <div class="panel panel-default">
               <div class="panel-heading d-flex justify-content-between align-items-center">
                  <h5 class="fw-bold mb-0 text-primary">Clients</h5>
                  <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#inviteModal">Invite Link</button>
               </div>
               <div class="panel-body">
                  <div class="table-responsive">
                     <table class="table table-striped table-bordered">
                        <thead>
                           <tr>
                              <th>S No</th>
                              <th>Client Name</th>
                              <th>Users</th>
                              <th>Total Generated URLs</th>
                              <th>Total URL Hits</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                 <td><?php echo e($clients->firstItem() + $index); ?></td>
                                 <td><?php echo e($client->name); ?></td>
                                 <td><?php echo e($client->users_count); ?></td>  
                                 <td><?php echo e($client->total_generated_urls ?? 0); ?></td> 
                                 <td><?php echo e($client->total_url_hits ?? 0); ?></td>
                              </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>
                  <!-- Pagination -->
                  <div class="d-flex justify-content-between align-items-center mt-3">
                     <div>Showing <?php echo e($clients->firstItem()); ?> to <?php echo e($clients->lastItem()); ?> of <?php echo e($clients->total()); ?> entries</div>
                     <nav>
                        <ul class="pagination mb-0">
                           <?php echo e($clients->links()); ?> <!-- Laravel Pagination Links -->
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
            <!-- End Clients Table -->
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\url_verse\resources\views/super_admin/clients.blade.php ENDPATH**/ ?>