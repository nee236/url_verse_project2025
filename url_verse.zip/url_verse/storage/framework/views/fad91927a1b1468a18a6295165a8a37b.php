
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Default Title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/nk.css')); ?>">
</head>
<body>
    
    <nav class="navbar navbar-expand-sm navbar-dark navbar-custom">
  <div class="container-fluid">
    <a class="navbar-brand" href="">Logo</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="">Dashboard</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Link</a>
        </li> -->
      </ul>
     
      <form class="d-flex" id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-danger" type="submit">Logout</button>
    </form>


    </div>
  </div>
</nav>

    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <!-- <footer>
        <p>&copy; <?php echo e(date('Y')); ?> My Website. All rights reserved.</p>
    </footer> -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\url_verse\resources\views/layouts/master.blade.php ENDPATH**/ ?>