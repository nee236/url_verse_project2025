<!-- resources/views/error.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8d7da;
            color: #721c24;
            padding: 20px;
            text-align: center;
        }
        .error-message {
            background-color: #f5c6cb;
            padding: 15px;
            border-radius: 5px;
            margin: 10px;
            font-size: 18px;
        }
    </style>
</head>
<body>

    <h1>Something went wrong</h1>

    <?php if(session('message')): ?>
        <div class="error-message">
            <p><?php echo e(session('message')); ?></p>
        </div>
    <?php else: ?>
        <div class="error-message">
            <p>Sorry, something unexpected happened.</p>
        </div>
    <?php endif; ?>

    <p><a href="<?php echo e(url('/')); ?>">Go back to homepage</a></p>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\url_verse\resources\views/error.blade.php ENDPATH**/ ?>